-- Analysis Tasks
-- 1.Show the first five records

SELECT TOP 5 * FROM Orders;

-- 2.Show the last five records
SELECT * FROM (
    SELECT TOP 5 * FROM Orders ORDER BY Order_Date DESC
) AS LastOrders
ORDER BY Order_Date ASC;

-- 3.How many rows and columns?
SELECT COUNT(*) AS TotalRows FROM Orders;
SELECT COUNT(*) AS TotalColumns
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'Orders';

-- 4.Show the statistical information using describe
SELECT 
    MIN(Quantity) AS MinQty,
    MAX(Quantity) AS MaxQty,
    AVG(Quantity) AS AvgQty,
    SUM(Quantity) AS TotalQty,

    MIN(Price) AS MinPrice,
    MAX(Price) AS MaxPrice,
    AVG(Price) AS AvgPrice,

    MIN(Delivery_Time_mins) AS MinDelivery,
    MAX(Delivery_Time_mins) AS MaxDelivery,
    AVG(Delivery_Time_mins) AS AvgDelivery
FROM Orders;

-- 5.Check for Null values
SELECT
    SUM(CASE WHEN Order_ID IS NULL THEN 1 ELSE 0 END) AS Null_OrderID,
    SUM(CASE WHEN Product_Name IS NULL THEN 1 ELSE 0 END) AS Null_ProductName,
    SUM(CASE WHEN Category IS NULL THEN 1 ELSE 0 END) AS Null_Category,
    SUM(CASE WHEN Quantity IS NULL THEN 1 ELSE 0 END) AS Null_Quantity,
    SUM(CASE WHEN Price IS NULL THEN 1 ELSE 0 END) AS Null_Price,
    SUM(CASE WHEN Discount IS NULL THEN 1 ELSE 0 END) AS Null_Discount,
    SUM(CASE WHEN Customer_City IS NULL THEN 1 ELSE 0 END) AS Null_CustomerCity,
    SUM(CASE WHEN Delivery_Time_mins IS NULL THEN 1 ELSE 0 END) AS Null_DeliveryTime,
    SUM(CASE WHEN Order_Date IS NULL THEN 1 ELSE 0 END) AS Null_OrderDate
FROM Orders;

-- 6.Check and remove duplicate values
WITH CTE AS (
    SELECT *, 
        ROW_NUMBER() OVER (PARTITION BY Order_ID, Product_Name, Category, Quantity, Price, Discount, Customer_City, Delivery_Time_mins, Order_Date ORDER BY Order_ID) AS rn
    FROM Orders
)
DELETE FROM CTE WHERE rn > 1;

-- Excel Charts
-- 1.Category vs Total Orders
SELECT Category, COUNT(*) AS TotalOrders
FROM Orders
GROUP BY Category;

-- 2.City vs Order Count
SELECT Customer_City, COUNT(*) AS OrderCount
FROM Orders
GROUP BY Customer_City;

-- 3.Discount vs Quantity
SELECT Discount, SUM(Quantity) AS TotalQuantity
FROM Orders
GROUP BY Discount;

-- 4.Year vs Revenue
SELECT YEAR(Order_Date) AS OrderYear,
       SUM(Price * Quantity) AS TotalRevenue
FROM Orders
GROUP BY YEAR(Order_Date)
ORDER BY OrderYear;

-- 5.City vs Avg. Delivery Time
SELECT Customer_City, AVG(Delivery_Time_mins) AS AvgDeliveryTime
FROM Orders
GROUP BY Customer_City;



